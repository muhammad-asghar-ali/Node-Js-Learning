const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();
const cookieParser = require('cookie-parser');
const authRoutes = require('./routes/authRoutes');
const { requireAuth, checkUser } = require('./middleware/authMiddleware');

const app = express();

// middleware
app.use(express.static('public'));
app.use(express.json());
app.use(cookieParser());

// view engine
app.set('view engine', 'ejs');

// database connection
// const dbURI = `mongodb+srv://${process.env.MONGO_ATLAS_DB}:${process.env.MONGO_ATLAS_PW}@cluster0.ogqvu.mongodb.net/myFirstDatabase`;
mongoose.connect(`mongodb://${process.env.MONGO_ATLAS_DB}:${process.env.MONGO_ATLAS_PW}@cluster0-shard-00-00.ogqvu.mongodb.net:27017,cluster0-shard-00-01.ogqvu.mongodb.net:27017,cluster0-shard-00-02.ogqvu.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-s9k7a0-shard-0&authSource=admin&retryWrites=true&w=majority`)
    .then((result) => app.listen(3000))
    .catch((err) => console.log(err));


// routes
app.get('*', checkUser)
app.get('/', (req, res) => res.render('home'));
app.get('/smoothies', requireAuth, (req, res) => res.render('smoothies'));
app.use(authRoutes);

// const port = process.env.PORT;
// const server = http.createServer(app); 
// server.listen(port);


// cookies

// app.get('/set-cookies', (req, res) => {

//   // res.setHeader('Set-Cookie', 'newUser=true');
  
//   res.cookie('newUser', false);
//   res.cookie('isEmployee', true, { maxAge: 1000 * 60 * 60 * 24, httpOnly: true });

//   res.send('you got the cookies!');

// });

// app.get('/read-cookies', (req, res) => {

//   const cookies = req.cookies;
//   console.log(cookies.newUser);

//   res.json(cookies);

// });