import express from 'express';
// body-parser is a middleware used for parsing the body from the request object during POST calls made to the server. 
import bodyParser from 'body-parser'; 
import tasksRoutes from './routes/tasks.js'


const app = express();
const PORT = 5500;
app.use(bodyParser.urlencoded());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
  }));

app.use('/tasks', tasksRoutes);

app.get('/', (req, res) => {
    // console.log("[TEST]");
    res.send("Hello from home page");
});

// app.get('/api/tasks', (req, res) => {
//     console.log("Get All the tasks from database");
//     res.send(['task1', 'task2', 'task3']);
// })

app.listen(5000, () => console.log(`Server Running on port http://localhost:${PORT}`));