import { v4 as uuidv4 } from 'uuid';
let tasks = [];

export const getUsers = (req, res) => {
    res.send(tasks);
}

export const createUser = (req, res) => {
    // request have property which is request.body
    const task = req.body;
    tasks.push({ ...task, id: uuidv4()});
    res.send(`New task Added to the Database ${task.taskName}`);
}

export const getUser = (req, res) => {
    // console.log(req.params);
    const { id } = req.params;
    const findTask = tasks.find(task => task.id === id);
 
    res.send(findTask);
}

export const deleteUser = (req, res) => {
    const { id } = req.params;

    tasks = tasks.filter(task => task.id !== id);
    res.send(`User with the id ${id} is deleted successfully`);
}

export const updateuser = (req, res) => {
    const { id } = req.params;
    const {taskName, status, startDate, endData, priority, projectName } = req.body;
    const task = tasks.find(task => task.id === id);

    if(taskName) task.taskName =  taskName;
    if(status) task.status = status;
    if(startDate) task.startDate = startDate;
    if(endData) task.endData = endData;
    if(priority) task.priority = priority;
    if(projectName) task.projectName = projectName;

    res.send(`the task with id ${id} is updated successfully`);
}

