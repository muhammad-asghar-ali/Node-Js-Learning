import express from 'express';
import { createUser, getUsers, getUser, deleteUser, updateuser } from '../controllers/tasks.js';

const router = express.Router();

// Get all the users
router.get('/', getUsers)

// post the data or create
router.post('/', createUser);

// Get te specific task
router.get('/:id', getUser);

// Delete the task 
router.delete('/:id', deleteUser);

// Patch 
router.patch('/:id', updateuser);

export default router;