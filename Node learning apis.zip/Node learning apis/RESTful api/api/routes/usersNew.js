import express from 'express';
import { user_signup, user_login, delete_user} from '../controllers/user.js';

const router = express.Router();

router.post('/signup', user_signup);

router.post('/login', user_login)


router.delete('/:userId', delete_user);

export default router;