import express from 'express';
import checkAuth from '../middleware/check-auth.js';

import {orders_get_all, create_order, get_order, delete_order} from '../controllers/orders.js';

const router = express.Router();

router.get('/', checkAuth, orders_get_all);

router.post('/', checkAuth, create_order);

router.get('/:orderId', checkAuth, get_order);

router.delete('/:orderId', checkAuth, delete_order);

export default router;