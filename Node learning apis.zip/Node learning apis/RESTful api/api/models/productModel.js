import  mongoose  from "mongoose";
// const mongoose = require('mongoose');
const prdouctSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name: {type: String, required: true},
    price: {type: Number, required: true},
    brand: {type: String, required: true}
});

// module.exports = mongoose.model('Product', prdouctSchema);
const Product = mongoose.model('Product', prdouctSchema);

export default Product;