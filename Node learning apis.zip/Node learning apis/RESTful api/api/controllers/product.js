import Product from '../models/productModel.js';
import mongoose  from 'mongoose';

const get_all_products = async (req, res, next) => {
    try{
        const products = await Product.find().select('name price _id brand').exec()
        res.status(200).json(products)
    }catch(err){
        console.log(err);
        res.status(500).json({error: err});
    }
}

const create_product = async (req, res, next) => {
    try{
        const product = new Product({
            _id: new mongoose.Types.ObjectId,
            name: req.body.name,
            price: req.body.price,
            brand: req.body.brand
        });
        const createProduct = await product.save();
        res.status(200).json(createProduct)
    }catch(err){
        console.log(err);
        res.status(500).json({error: err});
    }
}

const get_product = async (req, res, next) => {
    try{
        const id = req.params.productId;
        const product = await Product.findById(id).select('name, price, _id brand');
        if(product){
            res.status(200).json({
                product: product,
                    request: {
                        type: 'GET',
                        url: 'http://localhost:3000/products/'+id
                    }
            })
        }
        else{
            res.status(404).json({message: "No valid entry found for the provided ID"})
        }    
    }catch(err){
        console.log(err);
        res.status(500).json({error: err});
    }
}

const update_product = async (req, res, next) => {
    try{
        const id = req.params.productId
        const updateOps ={};
        for(const ops of req.body){
            updateOps[ops.propName] = ops.value;
        }
        await Product.updateOne({_id: id}, { $set: updateOps });

        res.status(200).json({
            message: 'Product Updated',
            request: {
                type: 'GET',
                url: 'http://localhost:3000/products'+id
            }
        })
    }catch(err){
        console.log(err);
        res.status(500).json({error: err});
    }
}

const delete_product = async (req, res, next) => {
    try{
        const id = req.params.productId
        await Product.remove({_id: id}).exec()

        res.status(200).json({
            message: "product Deleted",
            request: {
                type: 'POST',
                url: 'http://localhost:3000/products',
                body: {name: 'String', price: 'Number'}
            }
        })
    }catch(err){
        console.log(err);
        res.status(500).json({error: err});
    }
}
export {get_all_products, create_product, get_product, update_product, delete_product}