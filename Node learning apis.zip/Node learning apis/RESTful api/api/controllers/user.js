import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/userModel.js';

const user_signup = async (req, res, next) => {
    try{
        const findUser = await User.find({email: req.body.email});
        if(findUser.length >= 1){
            return res.status(409).json({
                message: "Mail exists"
            })
        }
        else{
            bcrypt.hash(req.body.password, 10, async (err, hash) => {
                if(!err){
                    const user = new User({
                        _id: new mongoose.Types.ObjectId(),
                        email: req.body.email,
                        password: hash,
                    })
                    const userCreated = await user.save();
                    console.log(userCreated)
                    res.status(201).json({
                        message: 'User Created'
                    });
                }
                else{
                    return res.status(500).json({
                        error: err
                    });
                }
            });
        }
    }catch(err){
        console.log(err);
        res.status(500).json({error: err});
    } 
}

const user_login = async (req, res, next) => {
    try{
        const findUser = await User.find({ email: req.body.email});
        if(findUser.length < 1){
            return res.status(401).json({
                message: "Auth Failed"
            })
        }
        bcrypt.compare(req.body.password, findUser[0].password, async (err, result) => {
            if(err){
                return res.status(401).json({
                    message: "Auth Failed"
                })
            }
            if(result){
                const token = jwt.sign(
                    {
                        email: findUser[0].email,
                        userId: findUser[0]._id
                    },
                    process.env.JWT_KEY,
                    {
                        expiresIn: "1h"
                    }
                )
                return res.status(200).json({
                    message: 'Auth successful',
                    token
                })
            }
            return res.status(401).json({
                message: "Auth Failed"
            })
        });
    }catch(err){
            res.status(500).json({
            error: err
        })
    }
}

const delete_user = async (req, res, next) => {
    try{
        await User.remove({_id: req.params.userId})
        res.status(200).json({
            message: 'User deleted'
        })
    }catch(err) {
        res.status(500).json({
            error: err
        })
    }
}

export { user_signup, user_login, delete_user}