import mongoose from 'mongoose';
import Order from '../models/orderModel.js'
import Product from '../models/productModel.js';

const orders_get_all = async (req, res, next) => {
    try{
        const orders = await Order.find().select('product quantity _id').populate('product', 'name');
        res.status(200).json(orders);
    }catch(err){
        console.log(err);
        res.status(500).json({error: err});
    }
}

const create_order = async (req, res, next) => {
    const product = await Product.findById({ _id: req.body.productId});
    if(!product){
        return res.status(404).json({
            message: 'Product Not Found'
        })
    } 
    try{
        const order = new Order({
            _id: new mongoose.Types.ObjectId(),
            quantity: req.body.quantity,
            product: req.body.productId        
        });
        const createOrder = await order.save();
        res.status(200).json(createOrder)
    }catch(err){
        console.log(err);
        res.status(500).json({error: err});
    } 
}

const get_order = async (req, res, next) => {
    try{
        const order = await Order.findById(req.params.orderId).populate('product');

        if(!order){
            return res.status(404).json({
                message: "Order Not Found"
            })
        }
        res.status(200).json({
            order: order,
            request: {
                type: "GET",
                url: "http://localhost:3000/orders"
            }
        })
    }catch(err){
        res.status(500).json({
            error: err
        })
    }
}

const delete_order = async (req, res, next) => {
    try{
        await Order.remove({_id: req.params.orderId});

        res.status(200).json({
            message: "Order Deleted",
            request: {
                type: "GET",
                url: "http://localhost:3000/orders",
                body: { productId: "ID", quantity: "Number"}
            }
        })
    }catch{
        res.status(500).json({
            error: err
        })
    }
}

export {orders_get_all, create_order, get_order, delete_order};
