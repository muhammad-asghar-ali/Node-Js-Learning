import express from 'express';
import mongoose  from 'mongoose';
import multer from 'multer';
import Product from '../Models/product.js';
import checkAuth from '../middleware/check-auth.js'

const router = express.Router();

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'uploads')
    },
    filename: function(req, file, cb) {
        cb(null, file .originalname);
    }
});
const fileFilter = (req, file, cb) => {
    if(file.mimetype === 'image/png' || file.mimetype === 'image/jpeg'){
        // accepts a file
        cb(null, true);
    }else{
        // reject a file 
        cb(null, false);
    }
}

const upload = multer({
    storage: storage, 
    limits: {
    fileSize: 1024 * 1024 *5
    },
    fileFilter: fileFilter
});

router.get('/', (req, res, next) => {
    Product.find()
    .select('name price _id ')
    .exec()
    .then(docs => {
        console.log(docs);
        const reposne = {
            count: docs.length,
            products: docs.map(doc => {
                return {
                    name: doc.name,
                    price: doc.price,
                    productImage: doc.productImage,
                    _id: doc._id,
                    request:{
                        type: 'GET',
                        url: "http://Localhost:5500/products/"+ doc._id   
                    }
                }
            })
        }
        res.status(200).json(reposne);
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({error: err})
    })
});

router.post('/', checkAuth, upload.single('productImage'),  (req, res, next) => {
    console.log(req.file);
    const product = new Product({
        _id: new mongoose.Types.ObjectId,
        name: req.body.name,
        price: req.body.price,
        productImage: req.file.path
    });

    product
    .save().then(result => {
        console.log(result);
        res.status(200).json({
            message:"Creating Product Successfully",
            createdProduct: {
                name: result.name,
                price: result.price,
                _id: result._id,
                productImage: result.path,
                request: {
                    type: "POST",
                    url: "http://localhost:5500/products/" + result._id
                }
            }
        });
    })
    .catch(err => { res.status(500).json({
            error: err        
        }) 
    });
});

router.get('/:productId', checkAuth, (req,res,next) => {
    const id = req.params.productId;
    Product.findById(id)
    .select('name, price, _id productImage')
    .exec()
    .then(doc => {
        console.log(doc);
        if(doc){
            res.status(200).json({
                product: doc,
                request: {
                    type: 'GET',
                    url: 'http://localhost:5500/products/'+id
                }
            })
        }else{
            res.status(404).json({message: "No valid entry found for the provided ID"})
        }
        
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({error: err});
    })
});

router.patch('/:productId', checkAuth, (req, res, next) => {
    const id = req.params.productId
    const updateOps ={};
    for(const ops of req.body){
        updateOps[ops.propName] = ops.value;
    }
    Product.updateOne({_id: id}, { $set: updateOps })
        .exec()
        .then(result => {
            console.log(result);
            res.status(200).json({
                message: 'Product Updated',
                request: {
                    type: 'GET',
                    url: 'http://localhost:5500/products'+id
                }
            })
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({error: err})
        })  
});

router.delete('/:productId', checkAuth, (req,res,next) => {
    const id = req.params.productId
    Product.remove({_id: id}).exec()
    .then(result => {
        console.log(result)
        res.status(200).json({
            message: "product Deleted",
            request: {
                type: 'POST',
                url: 'http://localhost:5500/products',
                body: {name: 'String', price: 'Number'}
            }
        })
    })
    .catch(err => {
        console.log(err)
        res.status(500).json({ error : err });
    })
});

export default router;
 