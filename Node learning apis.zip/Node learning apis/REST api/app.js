import express from 'express';
import morgan from 'morgan';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';

import productRoutes from './api/routes/products.js';
import orderRoutes from './api/routes/orders.js'
import userRoutes from './api/routes/users.js';

const app = express();
 
// mongoose.connect(`mongodb+srv://Nodedb:naxxa@cluster0.ogqvu.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`);
mongoose.connect(`mongodb://Nodedb:${process.env.MONGO_ATLAS_PW}@cluster0-shard-00-00.ogqvu.mongodb.net:27017,cluster0-shard-00-01.ogqvu.mongodb.net:27017,cluster0-shard-00-02.ogqvu.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-s9k7a0-shard-0&authSource=admin&retryWrites=true&w=majority`);

app.use(morgan('dev'));

app.use('/uploads', express.static('uploads'))
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

// app.use((req, res, next) => {
//     res.header('Access-Control-Allow-Origin', '*');
//     res.header('Access-Contorl-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
//     if(req.method === "OPTIONS"){
//         res.header('Access-Contorl-Allow-Methods', 'PUT, GET, POST, PATCH, DELETE');
//         return res.status(200).json({});
//     }
// });

app.use('/products', productRoutes);
app.use('/orders', orderRoutes);
app.use('/users', userRoutes);

app.use((req, res, next) => {
    const error = new Error('Not Found');
    error.status = 404;
    next(error);
});

app.use((error, req, res, next) =>{
    res.status(error.status || 500);
    res.json({
        error:{
            message: error.message
        }
    })
})

export default app;
